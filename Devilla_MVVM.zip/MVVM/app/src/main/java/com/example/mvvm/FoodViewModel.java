package com.example.mvvm;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import java.util.ArrayList;
import java.util.List;
public class FoodViewModel extends ViewModel {
    private MutableLiveData<List<FoodItems>> foodList;
    public LiveData<List<FoodItems>> getFoodList() {
        if (foodList == null) {
            foodList = new MutableLiveData<>();
            loadFoods();
        }
        return foodList;
    }
    private void loadFoods() {
        List<FoodItems> list = new ArrayList<>();
        list.add(new FoodItems("Pizza", "Cheesy and delicious", R.drawable.pizza));
        list.add(new FoodItems("Burger", "Try our juicy beef burger", R.drawable.burger));
        list.add(new FoodItems("Sushi", "Try our fresh salmon sushi", R.drawable.sushi));
        list.add(new FoodItems("Pasta", "Try our pasta", R.drawable.pasta));
        list.add(new FoodItems("Lasagna", "Try our cream cheese", R.drawable.lasagna));
        list.add(new FoodItems("Ice Tea", "Would you like to try our ice tea", R.drawable.icetea));
        list.add(new FoodItems("Hot Chocolate", "Would you like to try our hot chocolate", R.drawable.hotchocolote));
        list.add(new FoodItems("Cranberry Juice", "Would you like to try our cranberry juice", R.drawable.cranberryjuice));
        list.add(new FoodItems("Espresso", "Would you like to try our espresso", R.drawable.espresso));

        foodList.setValue(list);
    }
}
